<?php

/*
 * Funciones de apoyo compartidas por index.php y por los procesos.
 * No contienen SQL ni HTML.
 */

// Redirige a una página de index.php y detiene el script.
//   $pagina  : nombre de la página (inventario, login, registro...)
//   $mensaje : texto que se mostrará al usuario (opcional)
//   $tipo    : "exito" o "error"
//   $extra   : parámetros adicionales, por ejemplo "id=5"
function redirigir($pagina, $mensaje = "", $tipo = "exito", $extra = "")
{
    $url = URL_BASE . "index.php?pagina=" . urlencode($pagina);

    if ($extra !== "") {
        $url .= "&" . $extra;
    }

    if ($mensaje !== "") {
        $url .= "&mensaje=" . urlencode($mensaje) . "&tipo=" . urlencode($tipo);
    }

    header("Location: " . $url);
    exit();
}

// Guarda en sesión lo que el usuario escribió en el formulario para no
// obligarlo a escribirlo otra vez cuando hay un error de validación.
// Las contraseñas NUNCA se guardan.
function recordarCampos($campos)
{
    $guardado = [];

    foreach ($campos as $campo) {
        if (isset($_POST[$campo])) {
            $guardado[$campo] = trim($_POST[$campo]);
        }
    }

    $_SESSION["formulario_previo"] = $guardado;
}

// Devuelve lo recordado y lo borra (solo se usa una vez).
function recuperarFormulario()
{
    $previo = $_SESSION["formulario_previo"] ?? [];
    unset($_SESSION["formulario_previo"]);

    return $previo;
}
