<?php

// Carga la configuración con una ruta basada en la ubicación real de este archivo.
require_once __DIR__ . "/config.php";

// Evita que MySQLi muestre errores técnicos al usuario final.
mysqli_report(MYSQLI_REPORT_OFF);

// Crea la conexión con las constantes definidas en config.php.
$conexion = new mysqli(SERVIDOR, USUARIO, PASSWORD, BASE_DATOS);

// Si la conexión falla se detiene el programa con un mensaje claro.
if ($conexion->connect_errno) {
    die("No fue posible conectar con la base de datos. "
      . "Verifica que MySQL esté iniciado en XAMPP y que hayas importado BD/sparrow_db.sql.");
}

// UTF-8 completo para tildes, eñes y caracteres especiales.
$conexion->set_charset("utf8mb4");
