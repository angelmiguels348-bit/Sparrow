<?php

// Servidor donde está ejecutándose MySQL.
define("SERVIDOR", "localhost");

// Usuario de MySQL (en XAMPP es "root").
define("USUARIO", "root");

// Contraseña de MySQL (en XAMPP local normalmente está vacía).
define("PASSWORD", "");

// Nombre de la base de datos del proyecto.
define("BASE_DATOS", "sparrow_db");

/*
 * URL_BASE: ruta web de la carpeta del proyecto.
 * Ejemplo: si copias el proyecto a C:\xampp\htdocs\sparrow  ->  "/sparrow/"
 *
 * Se calcula sola a partir de la ubicación real de este archivo, así el
 * proyecto funciona aunque cambies el nombre de la carpeta. Se usa para
 * cargar CSS, JS e imágenes y para las redirecciones desde /procesos.
 */
$raizProyecto = str_replace("\\", "/", (string) realpath(__DIR__ . "/.."));
$raizWeb      = str_replace("\\", "/", (string) realpath($_SERVER["DOCUMENT_ROOT"] ?? ""));

$rutaWeb = "/";
if ($raizWeb !== "" && strpos($raizProyecto, $raizWeb) === 0) {
    $rutaWeb = substr($raizProyecto, strlen($raizWeb)) . "/";
}

// rawurlencode por segmento: permite carpetas con espacios o tildes.
$segmentos = array_map("rawurlencode", explode("/", $rutaWeb));
define("URL_BASE", implode("/", $segmentos));
