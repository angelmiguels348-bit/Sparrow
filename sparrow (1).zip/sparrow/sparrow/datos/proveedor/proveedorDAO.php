<?php

/*
 * DAO de proveedores: aquí están todas las consultas SQL de la tabla proveedores.
 * Todas las consultas filtran por usuario_id, así cada usuario solo puede ver
 * y modificar sus propios registros.
 * No contiene HTML ni validaciones.
 */

// Obtiene todos los registros del usuario.
// Devuelve un mysqli_result (o false si la consulta falla).
function listarProveedores($conexion, $usuarioId)
{
    $sql = "SELECT id, nombre, contacto
            FROM proveedores
            WHERE usuario_id = ?
            ORDER BY id ASC";

    $stmt = $conexion->prepare($sql);
    if (!$stmt) return false;

    // i = integer
    $stmt->bind_param("i", $usuarioId);
    $stmt->execute();

    $resultado = $stmt->get_result();
    $stmt->close();

    return $resultado;
}

// Inserta un registro nuevo para el usuario.
function insertarProveedor($conexion, $usuarioId, $nombre, $contacto)
{
    $sql = "INSERT INTO proveedores (usuario_id, nombre, contacto)
            VALUES (?, ?, ?)";

    $stmt = $conexion->prepare($sql);
    if (!$stmt) return false;

    // i = usuario_id, luego el tipo de cada campo (s = string, i = integer)
    $stmt->bind_param("iss", $usuarioId, $nombre, $contacto);
    $ok = $stmt->execute();
    $stmt->close();

    return $ok;
}

// Busca un registro por su ID (solo si pertenece al usuario).
// Devuelve un arreglo asociativo o null si no existe.
function buscarProveedor($conexion, $id, $usuarioId)
{
    $sql = "SELECT id, nombre, contacto
            FROM proveedores
            WHERE id = ? AND usuario_id = ?";

    $stmt = $conexion->prepare($sql);
    if (!$stmt) return null;

    $stmt->bind_param("ii", $id, $usuarioId);
    $stmt->execute();

    $registro = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return $registro;
}

// Actualiza un registro (solo si pertenece al usuario).
function actualizarProveedor($conexion, $id, $usuarioId, $nombre, $contacto)
{
    $sql = "UPDATE proveedores
            SET nombre = ?, contacto = ?
            WHERE id = ? AND usuario_id = ?";

    $stmt = $conexion->prepare($sql);
    if (!$stmt) return false;

    $stmt->bind_param("ssii", $nombre, $contacto, $id, $usuarioId);
    $ok = $stmt->execute();
    $stmt->close();

    return $ok;
}

// Elimina un registro (solo si pertenece al usuario).
function eliminarProveedor($conexion, $id, $usuarioId)
{
    $sql = "DELETE FROM proveedores WHERE id = ? AND usuario_id = ?";

    $stmt = $conexion->prepare($sql);
    if (!$stmt) return false;

    $stmt->bind_param("ii", $id, $usuarioId);
    $ok = $stmt->execute();
    $stmt->close();

    return $ok;
}
