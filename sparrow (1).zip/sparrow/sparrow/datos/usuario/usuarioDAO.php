<?php

/*
 * DAO de usuarios: aquí están todas las consultas SQL de la tabla usuarios.
 * No contiene HTML ni validaciones.
 */

// Busca un usuario por su nombre de usuario O por su correo (para el login).
// Devuelve un arreglo asociativo con los datos o null si no existe.
function buscarUsuarioPorLogin($conexion, $login)
{
    $sql = "SELECT id, nombre, usuario, correo, password_hash
            FROM usuarios
            WHERE usuario = ? OR correo = ?
            LIMIT 1";

    $stmt = $conexion->prepare($sql);
    if (!$stmt) return null;

    // s = string, s = string
    $stmt->bind_param("ss", $login, $login);
    $stmt->execute();

    $resultado = $stmt->get_result();
    $usuario = $resultado->fetch_assoc();
    $stmt->close();

    return $usuario;
}

// Comprueba si un nombre de usuario ya está registrado.
function existeUsuario($conexion, $usuario)
{
    $stmt = $conexion->prepare("SELECT id FROM usuarios WHERE usuario = ?");
    if (!$stmt) return true; // ante la duda, se bloquea el registro

    $stmt->bind_param("s", $usuario);
    $stmt->execute();

    $existe = $stmt->get_result()->num_rows > 0;
    $stmt->close();

    return $existe;
}

// Comprueba si un correo ya está registrado.
function existeCorreo($conexion, $correo)
{
    $stmt = $conexion->prepare("SELECT id FROM usuarios WHERE correo = ?");
    if (!$stmt) return true;

    $stmt->bind_param("s", $correo);
    $stmt->execute();

    $existe = $stmt->get_result()->num_rows > 0;
    $stmt->close();

    return $existe;
}

// Inserta un usuario nuevo. Recibe la contraseña YA cifrada (password_hash).
function insertarUsuario($conexion, $nombre, $usuario, $correo, $passwordHash)
{
    $sql = "INSERT INTO usuarios (nombre, usuario, correo, password_hash)
            VALUES (?, ?, ?, ?)";

    $stmt = $conexion->prepare($sql);
    if (!$stmt) return false;

    // s = string (los cuatro valores son texto)
    $stmt->bind_param("ssss", $nombre, $usuario, $correo, $passwordHash);
    $ok = $stmt->execute();
    $stmt->close();

    return $ok;
}
