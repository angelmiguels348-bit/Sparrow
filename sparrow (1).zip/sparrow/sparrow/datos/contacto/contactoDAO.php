<?php

/*
 * DAO de mensajes de contacto.
 */

// Guarda un mensaje enviado desde el formulario de contacto.
function insertarMensaje($conexion, $nombre, $correo, $mensaje)
{
    $sql = "INSERT INTO mensajes_contacto (nombre, correo, mensaje)
            VALUES (?, ?, ?)";

    $stmt = $conexion->prepare($sql);
    if (!$stmt) return false;

    $stmt->bind_param("sss", $nombre, $correo, $mensaje);
    $ok = $stmt->execute();
    $stmt->close();

    return $ok;
}
