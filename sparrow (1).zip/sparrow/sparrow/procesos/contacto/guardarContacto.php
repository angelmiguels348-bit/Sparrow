<?php

require_once __DIR__ . "/../../config/conexionBDD.php";
require_once __DIR__ . "/../../datos/contacto/contactoDAO.php";
require_once __DIR__ . "/../../logica/validarContacto.php";
require_once __DIR__ . "/../../logica/sesion.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    redirigir("contacto");
}

$error = validarContacto();

if ($error !== "") {
    recordarCampos(["txtNombre", "txtCorreo", "txtMensaje"]);
    redirigir("contacto", $error, "error");
}

$nombre  = trim($_POST["txtNombre"]);
$correo  = trim($_POST["txtCorreo"]);
$mensaje = trim($_POST["txtMensaje"]);

if (insertarMensaje($conexion, $nombre, $correo, $mensaje)) {
    redirigir("contacto", "Mensaje enviado exitosamente.");
}

recordarCampos(["txtNombre", "txtCorreo", "txtMensaje"]);
redirigir("contacto", "No fue posible enviar el mensaje.", "error");
