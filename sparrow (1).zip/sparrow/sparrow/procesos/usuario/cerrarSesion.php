<?php

require_once __DIR__ . "/../../config/config.php";
require_once __DIR__ . "/../../logica/sesion.php";

// Cerrar sesión solo se acepta por POST (botón "Salir" del menú).
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    redirigir(usuarioLogueado() ? "inventario" : "inicio");
}

// Vacía los datos de la sesión y elimina la cookie.
$_SESSION = [];

if (ini_get("session.use_cookies")) {
    $p = session_get_cookie_params();
    setcookie(session_name(), "", time() - 3600, $p["path"], $p["domain"], $p["secure"], $p["httponly"]);
}

session_destroy();

redirigir("login", "Sesión cerrada correctamente.");
