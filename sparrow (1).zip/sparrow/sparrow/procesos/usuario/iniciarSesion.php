<?php

require_once __DIR__ . "/../../config/conexionBDD.php";
require_once __DIR__ . "/../../datos/usuario/usuarioDAO.php";
require_once __DIR__ . "/../../logica/validarUsuario.php";
require_once __DIR__ . "/../../logica/sesion.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    redirigir("login");
}

$error = validarLogin();

if ($error !== "") {
    recordarCampos(["txtLogin"]);
    redirigir("login", $error, "error");
}

$login    = trim($_POST["txtLogin"]);
$password = $_POST["txtPassword"];

// Busca el usuario por nombre de usuario o por correo.
$usuario = buscarUsuarioPorLogin($conexion, $login);

// password_verify compara la contraseña escrita con el hash guardado.
// El mensaje es el mismo si falla el usuario o la contraseña, para no dar pistas.
if (!$usuario || !password_verify($password, $usuario["password_hash"])) {
    recordarCampos(["txtLogin"]);
    redirigir("login", "Este usuario no está registrado o la contraseña es incorrecta.", "error");
}

// Nuevo ID de sesión al autenticarse (evita la fijación de sesión).
session_regenerate_id(true);

$_SESSION["usuario_id"] = (int) $usuario["id"];
$_SESSION["usuario"]    = $usuario["usuario"];
$_SESSION["nombre"]     = $usuario["nombre"];

redirigir("inventario");
