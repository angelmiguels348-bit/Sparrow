<?php

require_once __DIR__ . "/../../config/conexionBDD.php";
require_once __DIR__ . "/../../datos/usuario/usuarioDAO.php";
require_once __DIR__ . "/../../logica/validarUsuario.php";
require_once __DIR__ . "/../../logica/sesion.php";

// Este proceso solo acepta el envío del formulario (POST).
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    redirigir("registro");
}

// Campos que se recuerdan si algo sale mal (nunca las contraseñas).
$camposRecordados = ["txtNombre", "txtUsuario", "txtCorreo"];

// 1) Validar el formulario.
$error = validarRegistro();

if ($error !== "") {
    recordarCampos($camposRecordados);
    redirigir("registro", $error, "error");
}

// 2) Limpiar los valores recibidos.
$nombre   = trim($_POST["txtNombre"]);
$usuario  = trim($_POST["txtUsuario"]);
$correo   = trim($_POST["txtCorreo"]);
$password = $_POST["txtPassword"];

// 3) Verificar que el usuario y el correo no estén en uso.
if (existeUsuario($conexion, $usuario)) {
    recordarCampos($camposRecordados);
    redirigir("registro", "Ese nombre de usuario ya está en uso.", "error");
}

if (existeCorreo($conexion, $correo)) {
    recordarCampos($camposRecordados);
    redirigir("registro", "Ese correo ya está registrado.", "error");
}

// 4) Cifrar la contraseña: en la base de datos NUNCA se guarda en texto plano.
$passwordHash = password_hash($password, PASSWORD_DEFAULT);

// 5) Solicitar al DAO la inserción.
if (insertarUsuario($conexion, $nombre, $usuario, $correo, $passwordHash)) {
    redirigir("login", "Cuenta creada correctamente. Ahora puedes iniciar sesión.");
}

recordarCampos($camposRecordados);
redirigir("registro", "No fue posible crear la cuenta. Intenta de nuevo.", "error");
