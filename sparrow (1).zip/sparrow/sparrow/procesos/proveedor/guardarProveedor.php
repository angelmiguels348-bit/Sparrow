<?php

require_once __DIR__ . "/../../config/conexionBDD.php";
require_once __DIR__ . "/../../datos/proveedor/proveedorDAO.php";
require_once __DIR__ . "/../../logica/validarProveedor.php";
require_once __DIR__ . "/../../logica/sesion.php";

// Solo usuarios con sesión iniciada.
$usuarioId = requerirSesion();

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    redirigir("proveedores");
}

// 1) Validar el formulario.
$error = validarProveedor();

if ($error !== "") {
    recordarCampos(["txtNombre", "txtContacto"]);
    redirigir("proveedores", $error, "error");
}

// 2) Limpiar los valores recibidos.
$nombre = trim($_POST["txtNombre"]);
$contacto = trim($_POST["txtContacto"]);

// 3) Solicitar al DAO la inserción.
if (insertarProveedor($conexion, $usuarioId, $nombre, $contacto)) {
    redirigir("proveedores", "Proveedor guardado correctamente.");
}

recordarCampos(["txtNombre", "txtContacto"]);
redirigir("proveedores", "No fue posible guardar el registro.", "error");
