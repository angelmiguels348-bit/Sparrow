<?php

require_once __DIR__ . "/../../config/conexionBDD.php";
require_once __DIR__ . "/../../datos/proveedor/proveedorDAO.php";
require_once __DIR__ . "/../../logica/validarProveedor.php";
require_once __DIR__ . "/../../logica/sesion.php";

$usuarioId = requerirSesion();

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    redirigir("proveedores");
}

$id = filter_var($_POST["id"] ?? 0, FILTER_VALIDATE_INT);

if (!$id) {
    redirigir("proveedores", "ID no válido.", "error");
}

// El registro debe existir y pertenecer al usuario conectado.
if (!buscarProveedor($conexion, $id, $usuarioId)) {
    redirigir("proveedores", "El registro no existe.", "error");
}

// Se repite la validación: el navegador puede ser manipulado.
$error = validarProveedor();

if ($error !== "") {
    recordarCampos(["txtNombre", "txtContacto"]);
    redirigir("proveedores-editar", $error, "error", "id=" . $id);
}

$nombre = trim($_POST["txtNombre"]);
$contacto = trim($_POST["txtContacto"]);

if (actualizarProveedor($conexion, $id, $usuarioId, $nombre, $contacto)) {
    redirigir("proveedores", "Proveedor actualizado correctamente.");
}

redirigir("proveedores", "No fue posible actualizar el registro.", "error");
