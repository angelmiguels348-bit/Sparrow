<?php

require_once __DIR__ . "/../../config/conexionBDD.php";
require_once __DIR__ . "/../../datos/proveedor/proveedorDAO.php";
require_once __DIR__ . "/../../logica/sesion.php";

$usuarioId = requerirSesion();

// Eliminar es una acción que modifica datos: solo se acepta por POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    redirigir("proveedores");
}

$id = filter_var($_POST["id"] ?? 0, FILTER_VALIDATE_INT);

if (!$id) {
    redirigir("proveedores", "ID no válido.", "error");
}

// Verifica que el registro exista y sea del usuario antes de eliminarlo.
if (!buscarProveedor($conexion, $id, $usuarioId)) {
    redirigir("proveedores", "El registro no existe.", "error");
}

if (eliminarProveedor($conexion, $id, $usuarioId)) {
    redirigir("proveedores", "Proveedor eliminado correctamente.");
}

redirigir("proveedores", "No fue posible eliminar el registro.", "error");
