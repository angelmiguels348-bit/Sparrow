<?php

require_once __DIR__ . "/../../config/conexionBDD.php";
require_once __DIR__ . "/../../datos/pedido/pedidoDAO.php";
require_once __DIR__ . "/../../logica/sesion.php";

$usuarioId = requerirSesion();

// Eliminar es una acción que modifica datos: solo se acepta por POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    redirigir("pedidos");
}

$id = filter_var($_POST["id"] ?? 0, FILTER_VALIDATE_INT);

if (!$id) {
    redirigir("pedidos", "ID no válido.", "error");
}

// Verifica que el registro exista y sea del usuario antes de eliminarlo.
if (!buscarPedido($conexion, $id, $usuarioId)) {
    redirigir("pedidos", "El registro no existe.", "error");
}

if (eliminarPedido($conexion, $id, $usuarioId)) {
    redirigir("pedidos", "Pedido eliminado correctamente.");
}

redirigir("pedidos", "No fue posible eliminar el registro.", "error");
