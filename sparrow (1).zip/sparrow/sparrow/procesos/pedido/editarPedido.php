<?php

/*
 * Proceso de edición: lo ejecuta index.php cuando se abre la página
 * "pedidos-editar". Busca el registro y deja la variable $registro
 * lista para el formulario de edición.
 */
require_once __DIR__ . "/../../config/conexionBDD.php";
require_once __DIR__ . "/../../datos/pedido/pedidoDAO.php";

$usuarioId = (int) $_SESSION["usuario_id"];

// Valida que el ID recibido por GET sea un entero.
$id = filter_var($_GET["id"] ?? 0, FILTER_VALIDATE_INT);

if (!$id) {
    redirigir("pedidos", "ID no válido.", "error");
}

// Busca el registro (solo si es del usuario conectado).
$registro = buscarPedido($conexion, $id, $usuarioId);

if (!$registro) {
    redirigir("pedidos", "El registro no existe.", "error");
}
