<?php

require_once __DIR__ . "/../../config/conexionBDD.php";
require_once __DIR__ . "/../../datos/pedido/pedidoDAO.php";
require_once __DIR__ . "/../../logica/validarPedido.php";
require_once __DIR__ . "/../../logica/sesion.php";

$usuarioId = requerirSesion();

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    redirigir("pedidos");
}

$id = filter_var($_POST["id"] ?? 0, FILTER_VALIDATE_INT);

if (!$id) {
    redirigir("pedidos", "ID no válido.", "error");
}

// El registro debe existir y pertenecer al usuario conectado.
if (!buscarPedido($conexion, $id, $usuarioId)) {
    redirigir("pedidos", "El registro no existe.", "error");
}

// Se repite la validación: el navegador puede ser manipulado.
$error = validarPedido();

if ($error !== "") {
    recordarCampos(["txtCliente", "txtDescripcion"]);
    redirigir("pedidos-editar", $error, "error", "id=" . $id);
}

$cliente = trim($_POST["txtCliente"]);
$descripcion = trim($_POST["txtDescripcion"]);

if (actualizarPedido($conexion, $id, $usuarioId, $cliente, $descripcion)) {
    redirigir("pedidos", "Pedido actualizado correctamente.");
}

redirigir("pedidos", "No fue posible actualizar el registro.", "error");
