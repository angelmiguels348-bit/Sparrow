<?php

require_once __DIR__ . "/../../config/conexionBDD.php";
require_once __DIR__ . "/../../datos/pedido/pedidoDAO.php";
require_once __DIR__ . "/../../logica/validarPedido.php";
require_once __DIR__ . "/../../logica/sesion.php";

// Solo usuarios con sesión iniciada.
$usuarioId = requerirSesion();

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    redirigir("pedidos");
}

// 1) Validar el formulario.
$error = validarPedido();

if ($error !== "") {
    recordarCampos(["txtCliente", "txtDescripcion"]);
    redirigir("pedidos", $error, "error");
}

// 2) Limpiar los valores recibidos.
$cliente = trim($_POST["txtCliente"]);
$descripcion = trim($_POST["txtDescripcion"]);

// 3) Solicitar al DAO la inserción.
if (insertarPedido($conexion, $usuarioId, $cliente, $descripcion)) {
    redirigir("pedidos", "Pedido registrado correctamente.");
}

recordarCampos(["txtCliente", "txtDescripcion"]);
redirigir("pedidos", "No fue posible guardar el registro.", "error");
