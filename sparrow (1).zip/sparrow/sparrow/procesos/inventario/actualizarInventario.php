<?php

require_once __DIR__ . "/../../config/conexionBDD.php";
require_once __DIR__ . "/../../datos/inventario/inventarioDAO.php";
require_once __DIR__ . "/../../logica/validarInventario.php";
require_once __DIR__ . "/../../logica/sesion.php";

$usuarioId = requerirSesion();

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    redirigir("inventario");
}

$id = filter_var($_POST["id"] ?? 0, FILTER_VALIDATE_INT);

if (!$id) {
    redirigir("inventario", "ID no válido.", "error");
}

// El registro debe existir y pertenecer al usuario conectado.
if (!buscarInventario($conexion, $id, $usuarioId)) {
    redirigir("inventario", "El registro no existe.", "error");
}

// Se repite la validación: el navegador puede ser manipulado.
$error = validarInventario();

if ($error !== "") {
    recordarCampos(["txtDetalle", "txtCantidad"]);
    redirigir("inventario-editar", $error, "error", "id=" . $id);
}

$detalle = trim($_POST["txtDetalle"]);
$cantidad = (int) trim($_POST["txtCantidad"]);

if (actualizarInventario($conexion, $id, $usuarioId, $detalle, $cantidad)) {
    redirigir("inventario", "Registro de inventario actualizado correctamente.");
}

redirigir("inventario", "No fue posible actualizar el registro.", "error");
