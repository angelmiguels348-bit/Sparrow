<?php

/*
 * Proceso de lectura: lo ejecuta index.php ANTES de cargar la vista.
 * Aquí nacen las variables $resultado y $total que usa la vista.
 */
require_once __DIR__ . "/../../config/conexionBDD.php";
require_once __DIR__ . "/../../datos/inventario/inventarioDAO.php";

// index.php ya comprobó que hay sesión iniciada.
$usuarioId = (int) $_SESSION["usuario_id"];

// Ejecuta la consulta mediante el DAO.
$resultado = listarInventario($conexion, $usuarioId);

if ($resultado === false) {
    die("No fue posible consultar los registros.");
}

// Cantidad de registros devueltos.
$total = $resultado->num_rows;
