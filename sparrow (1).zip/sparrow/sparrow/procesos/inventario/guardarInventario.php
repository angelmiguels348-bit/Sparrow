<?php

require_once __DIR__ . "/../../config/conexionBDD.php";
require_once __DIR__ . "/../../datos/inventario/inventarioDAO.php";
require_once __DIR__ . "/../../logica/validarInventario.php";
require_once __DIR__ . "/../../logica/sesion.php";

// Solo usuarios con sesión iniciada.
$usuarioId = requerirSesion();

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    redirigir("inventario");
}

// 1) Validar el formulario.
$error = validarInventario();

if ($error !== "") {
    recordarCampos(["txtDetalle", "txtCantidad"]);
    redirigir("inventario", $error, "error");
}

// 2) Limpiar los valores recibidos.
$detalle = trim($_POST["txtDetalle"]);
$cantidad = (int) trim($_POST["txtCantidad"]);

// 3) Solicitar al DAO la inserción.
if (insertarInventario($conexion, $usuarioId, $detalle, $cantidad)) {
    redirigir("inventario", "Registro guardado en el inventario.");
}

recordarCampos(["txtDetalle", "txtCantidad"]);
redirigir("inventario", "No fue posible guardar el registro.", "error");
