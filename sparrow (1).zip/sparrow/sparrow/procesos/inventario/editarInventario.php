<?php

/*
 * Proceso de edición: lo ejecuta index.php cuando se abre la página
 * "inventario-editar". Busca el registro y deja la variable $registro
 * lista para el formulario de edición.
 */
require_once __DIR__ . "/../../config/conexionBDD.php";
require_once __DIR__ . "/../../datos/inventario/inventarioDAO.php";

$usuarioId = (int) $_SESSION["usuario_id"];

// Valida que el ID recibido por GET sea un entero.
$id = filter_var($_GET["id"] ?? 0, FILTER_VALIDATE_INT);

if (!$id) {
    redirigir("inventario", "ID no válido.", "error");
}

// Busca el registro (solo si es del usuario conectado).
$registro = buscarInventario($conexion, $id, $usuarioId);

if (!$registro) {
    redirigir("inventario", "El registro no existe.", "error");
}
