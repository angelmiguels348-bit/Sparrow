<?php

require_once __DIR__ . "/../../config/conexionBDD.php";
require_once __DIR__ . "/../../datos/inventario/inventarioDAO.php";
require_once __DIR__ . "/../../logica/sesion.php";

$usuarioId = requerirSesion();

// Eliminar es una acción que modifica datos: solo se acepta por POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    redirigir("inventario");
}

$id = filter_var($_POST["id"] ?? 0, FILTER_VALIDATE_INT);

if (!$id) {
    redirigir("inventario", "ID no válido.", "error");
}

// Verifica que el registro exista y sea del usuario antes de eliminarlo.
if (!buscarInventario($conexion, $id, $usuarioId)) {
    redirigir("inventario", "El registro no existe.", "error");
}

if (eliminarInventario($conexion, $id, $usuarioId)) {
    redirigir("inventario", "Registro eliminado del inventario.");
}

redirigir("inventario", "No fue posible eliminar el registro.", "error");
