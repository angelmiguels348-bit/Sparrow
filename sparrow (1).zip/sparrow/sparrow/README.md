# SPARROW – PHP estructurado + MySQLi (arquitectura por capas)

Administración de toallas en microfibra: inventario, pedidos y proveedores, con registro
e inicio de sesión de usuarios. Sigue la arquitectura de las Guías del Proyecto 04
(config · datos · logica · procesos · vistas), sin MVC, POO ni PDO.

## 1. Ejecutarlo en XAMPP

1. Copia esta carpeta (`sparrow`) dentro de `C:\xampp\htdocs\`.
2. Abre el Panel de XAMPP e inicia **Apache** y **MySQL**.
3. Abre `http://localhost/phpmyadmin` → pestaña **Importar** → elige `BD/sparrow_db.sql` → **Importar**.
   (Crea la base de datos `sparrow_db` con sus tablas. Si la vuelves a importar, se borran los datos.)
4. Abre `http://localhost/sparrow/`

| Acceso de demostración | Valor |
|---|---|
| Usuario | `admin` (también sirve `admin@sparrow.com`) |
| Contraseña | `1234` |

Para crear tu propia cuenta usa **Registrarse** en el menú.

## 2. Estructura

```
sparrow/
├── config/
│   ├── config.php            constantes (servidor, usuario, contraseña, base de datos, URL_BASE)
│   ├── conexionBDD.php       crea la conexión $conexion (MySQLi)
│   └── utilidades.php        redirigir(), recordarCampos(), recuperarFormulario()
├── datos/                    SOLO consultas SQL (prepare + bind_param)
│   ├── usuario/usuarioDAO.php
│   ├── inventario/inventarioDAO.php
│   ├── pedido/pedidoDAO.php
│   ├── proveedor/proveedorDAO.php
│   └── contacto/contactoDAO.php
├── logica/                   reglas de validación y sesión
│   ├── sesion.php            session_start, usuarioLogueado(), requerirSesion()
│   ├── validarUsuario.php    validarRegistro(), validarLogin()
│   ├── validarInventario.php · validarPedido.php · validarProveedor.php · validarContacto.php
├── procesos/                 coordinan cada operación (validan → llaman al DAO → redirigen)
│   ├── usuario/     registrarUsuario · iniciarSesion · cerrarSesion
│   ├── inventario/  listar · guardar · editar · actualizar · eliminar
│   ├── pedido/      listar · guardar · editar · actualizar · eliminar
│   ├── proveedor/   listar · guardar · editar · actualizar · eliminar
│   └── contacto/    guardarContacto
├── vistas/                   solo HTML + pequeñas instrucciones PHP
│   ├── plantilla/   encabezado · mensaje · bannerUsuario · pie
│   ├── publico/     inicio · informacion · contacto
│   ├── usuario/     formularioLogin · formularioRegistro
│   └── inventario/ pedido/ proveedor/   formulario · formularioEditar · lista
├── css/estilos.css
├── js/funciones.js           comodidades de interfaz (la validación real está en PHP)
├── img/imagen.jpg
├── BD/sparrow_db.sql
└── index.php                 punto de entrada
```

## 3. Flujo de la aplicación

**Listar (READ)**

```
index.php?pagina=inventario
   ↓ index.php comprueba la sesión
procesos/inventario/listarInventario.php   → crea $resultado y $total
   ↓
datos/inventario/inventarioDAO.php  →  MySQL (SELECT preparado)
   ↓
vistas/inventario/listaInventario.php
```

**Guardar (CREATE)**

```
vistas/.../formularioInventario.php  (POST)
   ↓
procesos/inventario/guardarInventario.php
   ↓ logica/validarInventario.php
   ↓ datos/inventario/inventarioDAO.php  →  INSERT preparado
   ↓ header() + exit()
index.php?pagina=inventario&mensaje=...
```

**Registro de usuario**

```
formularioRegistro (POST) → procesos/usuario/registrarUsuario.php
   → validarRegistro()  → existeUsuario() / existeCorreo()
   → password_hash()    → insertarUsuario()  → redirige al login
```

## 4. Reglas del registro

- Nombre: 3–80 caracteres, solo letras y espacios.
- Usuario: 4–30 caracteres (letras, números o guion bajo); único (sin distinguir mayúsculas).
- Correo: válido y único.
- Contraseña: 6–72 caracteres, con al menos una letra y un número; se guarda cifrada con `password_hash()`.

## 5. ¿Qué archivo modifico para…?

| Quiero… | Base de datos | DAO | Lógica / proceso | Vista |
|---|---|---|---|---|
| Agregar un campo (ej. teléfono en proveedores) | `BD/sparrow_db.sql` | `proveedorDAO.php` (SQL y `bind_param`) | `validarProveedor.php`, `guardar/actualizarProveedor.php` | `formularioProveedor.php`, `formularioEditar.php`, `listaProveedores.php` |
| Cambiar una regla de validación | – | – | archivo `logica/validar…` | – |
| Cambiar la contraseña/usuario de MySQL | – | – | `config/config.php` | – |
| Cambiar colores o diseño | – | – | – | `css/estilos.css` |
| Agregar un módulo nuevo | tabla nueva | DAO nuevo | procesos + validación nuevos | vistas nuevas + una entrada en `$paginas` de `index.php` |

## 6. Seguridad aplicada

- Consultas preparadas (`prepare`, `bind_param`, `execute`) en todas las operaciones con datos.
- Contraseñas con `password_hash()` / `password_verify()`; `session_regenerate_id()` al iniciar sesión.
- Salida escapada con `htmlspecialchars()` en todas las vistas.
- Cada usuario solo ve, edita y elimina **sus propios** registros (todas las consultas filtran por `usuario_id`).
- Eliminar y cerrar sesión se hacen por POST (no por enlaces).
- Las carpetas `config`, `datos`, `logica`, `vistas` y `BD` traen un `.htaccess` que bloquea el acceso directo desde el navegador.

## 7. Problemas frecuentes

- **"No fue posible conectar con la base de datos"**: MySQL no está iniciado o no se importó `BD/sparrow_db.sql`.
- **MySQL con contraseña**: escríbela en `PASSWORD` dentro de `config/config.php`.
- **Apache en otro puerto** (ej. 8080): abre `http://localhost:8080/sparrow/`.
- **Puedes renombrar la carpeta** sin tocar el código: `URL_BASE` se calcula sola.
