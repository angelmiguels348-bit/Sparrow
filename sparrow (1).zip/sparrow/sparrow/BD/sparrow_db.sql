CREATE DATABASE IF NOT EXISTS sparrow_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

USE sparrow_db;

-- Se borran en orden inverso a las dependencias para poder re-importar
DROP TABLE IF EXISTS mensajes_contacto;
DROP TABLE IF EXISTS proveedores;
DROP TABLE IF EXISTS pedidos;
DROP TABLE IF EXISTS inventario;
DROP TABLE IF EXISTS usuarios;


CREATE TABLE usuarios (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre        VARCHAR(80)  NOT NULL,
  usuario       VARCHAR(30)  NOT NULL,
  correo        VARCHAR(100) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  creado_en     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_usuario (usuario),
  UNIQUE KEY uq_correo (correo)
) ENGINE=InnoDB;


CREATE TABLE inventario (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  usuario_id INT UNSIGNED NOT NULL,
  detalle    VARCHAR(150) NOT NULL,
  cantidad   INT          NOT NULL DEFAULT 0,
  creado_en  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_inventario_usuario (usuario_id),
  CONSTRAINT fk_inventario_usuario FOREIGN KEY (usuario_id)
    REFERENCES usuarios (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;


CREATE TABLE pedidos (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  usuario_id  INT UNSIGNED NOT NULL,
  cliente     VARCHAR(150) NOT NULL,
  descripcion VARCHAR(255) NOT NULL,
  creado_en   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_pedidos_usuario (usuario_id),
  CONSTRAINT fk_pedidos_usuario FOREIGN KEY (usuario_id)
    REFERENCES usuarios (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE proveedores (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  usuario_id INT UNSIGNED NOT NULL,
  nombre     VARCHAR(150) NOT NULL,
  contacto   VARCHAR(100) NOT NULL,
  creado_en  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_proveedores_usuario (usuario_id),
  CONSTRAINT fk_proveedores_usuario FOREIGN KEY (usuario_id)
    REFERENCES usuarios (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE mensajes_contacto (
  id        INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre    VARCHAR(100) NOT NULL,
  correo    VARCHAR(100) NOT NULL,
  mensaje   TEXT         NOT NULL,
  creado_en TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB;


INSERT INTO usuarios (nombre, usuario, correo, password_hash) VALUES
('Administrador', 'admin', 'admin@sparrow.com', '$2y$10$fG25cE4RspayWIbjTGg9beEgSWco4XFTdfBsNz4W/bSWY7x98KV.q');

-- Datos de ejemplo para ver la plataforma funcionando (puedes borrarlos)
INSERT INTO inventario (usuario_id, detalle, cantidad) VALUES
(1, 'Toalla Microfibra Azul 40x40cm', 100),
(1, 'Toalla Microfibra Roja 40x40cm', 80),
(1, 'Toalla Microfibra Amarilla 30x30cm', 60);

INSERT INTO pedidos (usuario_id, cliente, descripcion) VALUES
(1, 'Empresa de Limpieza X', '50 toallas rojas y 20 amarillas');

INSERT INTO proveedores (usuario_id, nombre, contacto) VALUES
(1, 'Microfibras del Norte S.A.', '300 123 4567');
