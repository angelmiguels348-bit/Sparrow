<?php

/*
 * index.php: punto de entrada de SPARROW.
 *
 * Flujo de cada petición:
 *   1. Se identifica la página pedida (?pagina=...).
 *   2. Si es privada y no hay sesión, se envía al login.
 *   3. Si la página necesita datos, se ejecuta su PROCESO (crea $resultado,
 *      $total, $registro...).
 *   4. Se cargan las VISTAS: encabezado, mensaje, contenido y pie.
 */
require_once __DIR__ . "/config/config.php";
require_once __DIR__ . "/logica/sesion.php";

// ---------------------------------------------------------------------
// Mapa de páginas permitidas (lista blanca).
//   privada : requiere sesión iniciada
//   invitado: solo para quien NO ha iniciado sesión (login / registro)
//   proceso : archivo de /procesos que prepara los datos (opcional)
//   vistas  : archivos de /vistas que se muestran, en orden
// ---------------------------------------------------------------------
$paginas = [
    "inicio"      => ["vistas" => ["publico/inicio.php"]],
    "informacion" => ["vistas" => ["publico/informacion.php"]],
    "contacto"    => ["vistas" => ["publico/contacto.php"]],

    "login"    => ["invitado" => true, "vistas" => ["usuario/formularioLogin.php"]],
    "registro" => ["invitado" => true, "vistas" => ["usuario/formularioRegistro.php"]],

    "inventario" => [
        "privada" => true,
        "proceso" => "inventario/listarInventario.php",
        "vistas"  => ["inventario/formularioInventario.php", "inventario/listaInventario.php"],
    ],
    "inventario-editar" => [
        "privada" => true,
        "proceso" => "inventario/editarInventario.php",
        "vistas"  => ["inventario/formularioEditar.php"],
    ],

    "pedidos" => [
        "privada" => true,
        "proceso" => "pedido/listarPedidos.php",
        "vistas"  => ["pedido/formularioPedido.php", "pedido/listaPedidos.php"],
    ],
    "pedidos-editar" => [
        "privada" => true,
        "proceso" => "pedido/editarPedido.php",
        "vistas"  => ["pedido/formularioEditar.php"],
    ],

    "proveedores" => [
        "privada" => true,
        "proceso" => "proveedor/listarProveedores.php",
        "vistas"  => ["proveedor/formularioProveedor.php", "proveedor/listaProveedores.php"],
    ],
    "proveedores-editar" => [
        "privada" => true,
        "proceso" => "proveedor/editarProveedor.php",
        "vistas"  => ["proveedor/formularioEditar.php"],
    ],
];

// ---------------------------------------------------------------------
// 1) Página solicitada y mensaje de la última operación
// ---------------------------------------------------------------------
$pagina = $_GET["pagina"] ?? "inicio";

if (!is_string($pagina) || !isset($paginas[$pagina])) {
    $pagina = "inicio";
}

$mensaje = (isset($_GET["mensaje"]) && is_string($_GET["mensaje"])) ? $_GET["mensaje"] : "";
$tipo    = (($_GET["tipo"] ?? "") === "error") ? "error" : "exito";

$definicion = $paginas[$pagina];
$esPrivada  = !empty($definicion["privada"]);

// ---------------------------------------------------------------------
// 2) Control de acceso
// ---------------------------------------------------------------------
if ($esPrivada && !usuarioLogueado()) {
    redirigir("login", "Debes iniciar sesión para continuar.", "error");
}

if (!empty($definicion["invitado"]) && usuarioLogueado()) {
    redirigir("inventario");
}

// Cabeceras de seguridad básicas.
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");

// Las páginas privadas no se guardan en caché (al cerrar sesión, el botón
// "Atrás" no debe mostrar información del usuario).
if ($esPrivada) {
    header("Cache-Control: no-store");
}

// ---------------------------------------------------------------------
// 3) Proceso que prepara los datos (antes de cargar las vistas)
// ---------------------------------------------------------------------
if (isset($definicion["proceso"])) {
    require_once __DIR__ . "/procesos/" . $definicion["proceso"];
}

// Valores que el usuario había escrito en un formulario con errores.
$previo = recuperarFormulario();

// ---------------------------------------------------------------------
// 4) Vistas
// ---------------------------------------------------------------------
require_once __DIR__ . "/vistas/plantilla/encabezado.php";
?>

<section class="pagina">
    <?php
    require __DIR__ . "/vistas/plantilla/mensaje.php";

    if ($esPrivada) {
        require __DIR__ . "/vistas/plantilla/bannerUsuario.php";
    }

    foreach ($definicion["vistas"] as $vista) {
        require __DIR__ . "/vistas/" . $vista;
    }
    ?>
</section>

<?php
require_once __DIR__ . "/vistas/plantilla/pie.php";
