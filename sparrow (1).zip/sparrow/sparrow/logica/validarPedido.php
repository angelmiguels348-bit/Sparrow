<?php

/*
 * Reglas de validación de los pedidos.
 */
function validarPedido()
{
    if (!isset($_POST["txtCliente"], $_POST["txtDescripcion"])) {
        return "Por favor completa los dos campos.";
    }

    $cliente     = trim($_POST["txtCliente"]);
    $descripcion = trim($_POST["txtDescripcion"]);

    if ($cliente === "" || $descripcion === "") {
        return "Por favor completa los dos campos.";
    }

    if (mb_strlen($cliente, "UTF-8") < 3 || mb_strlen($cliente, "UTF-8") > 150) {
        return "El cliente debe tener entre 3 y 150 caracteres.";
    }

    if (mb_strlen($descripcion, "UTF-8") < 3 || mb_strlen($descripcion, "UTF-8") > 255) {
        return "La descripción debe tener entre 3 y 255 caracteres.";
    }

    return "";
}
