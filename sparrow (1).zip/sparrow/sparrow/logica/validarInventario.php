<?php

/*
 * Reglas de validación del inventario.
 * Devuelve "" si todo está bien, o el mensaje del primer error.
 */
function validarInventario()
{
    // Verifica que los campos hayan llegado por POST.
    if (!isset($_POST["txtDetalle"], $_POST["txtCantidad"])) {
        return "Por favor completa los dos campos.";
    }

    $detalle       = trim($_POST["txtDetalle"]);
    $cantidadTexto = trim($_POST["txtCantidad"]);

    // Se compara contra "" para no rechazar la cantidad 0 (empty() la rechazaría).
    if ($detalle === "" || $cantidadTexto === "") {
        return "Por favor completa los dos campos.";
    }

    if (mb_strlen($detalle, "UTF-8") < 3 || mb_strlen($detalle, "UTF-8") > 150) {
        return "El detalle debe tener entre 3 y 150 caracteres.";
    }

    // La cantidad debe ser un entero entre 0 y 1.000.000.
    $cantidad = filter_var($cantidadTexto, FILTER_VALIDATE_INT, [
        "options" => ["min_range" => 0, "max_range" => 1000000]
    ]);

    if ($cantidad === false) {
        return "La cantidad debe ser un número entero entre 0 y 1.000.000.";
    }

    return "";
}
