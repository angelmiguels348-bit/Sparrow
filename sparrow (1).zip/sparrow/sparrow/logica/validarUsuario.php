<?php

/*
 * Reglas de validación para el registro y el inicio de sesión.
 * Cada función devuelve "" si todo está bien, o el mensaje del primer error.
 */

// ---------------------------------------------------------------------
// FORMULARIO DE REGISTRO
// ---------------------------------------------------------------------
function validarRegistro()
{
    // Verifica que todos los campos hayan llegado por POST.
    if (!isset(
        $_POST["txtNombre"],
        $_POST["txtUsuario"],
        $_POST["txtCorreo"],
        $_POST["txtPassword"],
        $_POST["txtPassword2"]
    )) {
        return "Todos los campos son obligatorios.";
    }

    $nombre    = trim($_POST["txtNombre"]);
    $usuario   = trim($_POST["txtUsuario"]);
    $correo    = trim($_POST["txtCorreo"]);
    $password  = $_POST["txtPassword"];   // la contraseña no se recorta
    $password2 = $_POST["txtPassword2"];

    // Comparación contra "" para no confundir con empty().
    if ($nombre === "" || $usuario === "" || $correo === "" || $password === "" || $password2 === "") {
        return "Todos los campos son obligatorios.";
    }

    // Nombre completo: solo letras, espacios, punto, apóstrofo y guion.
    if (mb_strlen($nombre, "UTF-8") < 3 || mb_strlen($nombre, "UTF-8") > 80) {
        return "El nombre debe tener entre 3 y 80 caracteres.";
    }
    if (!preg_match("/^[\p{L}][\p{L}\s.'-]*$/u", $nombre)) {
        return "El nombre solo puede contener letras y espacios.";
    }

    // Usuario: letras, números y guion bajo; entre 4 y 30 caracteres.
    if (!preg_match("/^[A-Za-z0-9_]{4,30}$/", $usuario)) {
        return "El usuario debe tener entre 4 y 30 caracteres: letras, números o guion bajo (sin espacios).";
    }

    // Correo electrónico.
    if (strlen($correo) > 100 || !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        return "El correo electrónico no es válido.";
    }

    // Contraseña: 6 a 72 caracteres (límite de bcrypt), con al menos una letra y un número.
    if (strlen($password) < 6 || strlen($password) > 72) {
        return "La contraseña debe tener entre 6 y 72 caracteres.";
    }
    if (!preg_match("/[A-Za-z]/", $password) || !preg_match("/[0-9]/", $password)) {
        return "La contraseña debe incluir al menos una letra y un número.";
    }

    // Confirmación.
    if ($password !== $password2) {
        return "Las contraseñas no coinciden.";
    }

    return "";
}

// ---------------------------------------------------------------------
// FORMULARIO DE INICIO DE SESIÓN
// ---------------------------------------------------------------------
function validarLogin()
{
    if (!isset($_POST["txtLogin"], $_POST["txtPassword"])) {
        return "Completa usuario y contraseña.";
    }

    if (trim($_POST["txtLogin"]) === "" || $_POST["txtPassword"] === "") {
        return "Completa usuario y contraseña.";
    }

    return "";
}
