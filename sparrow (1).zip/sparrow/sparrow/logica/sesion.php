<?php

require_once __DIR__ . "/../config/config.php";
require_once __DIR__ . "/../config/utilidades.php";

/*
 * Manejo de la sesión del usuario.
 * Se incluye al inicio de index.php y de cada proceso que necesite saber
 * quién está conectado.
 */

if (session_status() === PHP_SESSION_NONE) {
    // Nombre propio para que no choque con otros proyectos de localhost.
    session_name("SPARROWSESSID");

    // La cookie no es accesible desde JavaScript.
    session_set_cookie_params([
        "httponly" => true,
        "samesite" => "Lax"
    ]);

    session_start();
}

// true si hay un usuario con sesión iniciada.
function usuarioLogueado()
{
    return !empty($_SESSION["usuario_id"]);
}

// Se usa al inicio de los procesos privados: si no hay sesión, vuelve al login.
// Si la hay, devuelve el ID del usuario conectado.
function requerirSesion()
{
    if (!usuarioLogueado()) {
        redirigir("login", "Debes iniciar sesión para continuar.", "error");
    }

    return (int) $_SESSION["usuario_id"];
}
