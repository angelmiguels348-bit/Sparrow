<?php

/*
 * Reglas de validación de los proveedores.
 */
function validarProveedor()
{
    if (!isset($_POST["txtNombre"], $_POST["txtContacto"])) {
        return "Por favor completa los dos campos.";
    }

    $nombre   = trim($_POST["txtNombre"]);
    $contacto = trim($_POST["txtContacto"]);

    if ($nombre === "" || $contacto === "") {
        return "Por favor completa los dos campos.";
    }

    if (mb_strlen($nombre, "UTF-8") < 3 || mb_strlen($nombre, "UTF-8") > 150) {
        return "El nombre del proveedor debe tener entre 3 y 150 caracteres.";
    }

    if (mb_strlen($contacto, "UTF-8") < 5 || mb_strlen($contacto, "UTF-8") > 100) {
        return "El teléfono o contacto debe tener entre 5 y 100 caracteres.";
    }

    return "";
}
