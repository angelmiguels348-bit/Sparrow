<?php

/*
 * Reglas de validación del formulario de contacto.
 */
function validarContacto()
{
    if (!isset($_POST["txtNombre"], $_POST["txtCorreo"], $_POST["txtMensaje"])) {
        return "Todos los campos son obligatorios.";
    }

    $nombre  = trim($_POST["txtNombre"]);
    $correo  = trim($_POST["txtCorreo"]);
    $mensaje = trim($_POST["txtMensaje"]);

    if ($nombre === "" || $correo === "" || $mensaje === "") {
        return "Todos los campos son obligatorios.";
    }

    if (mb_strlen($nombre, "UTF-8") < 3 || mb_strlen($nombre, "UTF-8") > 100) {
        return "El nombre debe tener entre 3 y 100 caracteres.";
    }

    // El nombre no puede contener números.
    if (preg_match("/\d/", $nombre)) {
        return "El nombre no puede contener números.";
    }

    if (strlen($correo) > 100 || !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        return "El correo electrónico no es válido.";
    }

    if (mb_strlen($mensaje, "UTF-8") < 3 || mb_strlen($mensaje, "UTF-8") > 1000) {
        return "El mensaje debe tener entre 3 y 1000 caracteres.";
    }

    return "";
}
