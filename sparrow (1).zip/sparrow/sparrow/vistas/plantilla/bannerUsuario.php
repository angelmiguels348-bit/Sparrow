<div class="user-banner">
    <span>Sesión activa: <strong><?= htmlspecialchars($_SESSION["usuario"]) ?></strong></span>
</div>
