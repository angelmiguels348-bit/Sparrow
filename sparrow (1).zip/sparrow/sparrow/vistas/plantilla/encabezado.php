<?php
// Devuelve " activo" si la página actual empieza por el nombre indicado.
$claseActiva = function ($nombre) use ($pagina) {
    return strpos($pagina, $nombre) === 0 ? " activo" : "";
};
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Proyecto de Grado - SPARROW</title>
    <link rel="stylesheet" href="<?= URL_BASE ?>css/estilos.css">
</head>
<body>

<header>
    <div class="logo">SPARROW</div>

    <nav>
        <?php if (!usuarioLogueado()): ?>

            <!-- Menú público -->
            <a href="<?= URL_BASE ?>index.php?pagina=inicio" class="<?= $claseActiva("inicio") ?>">Inicio</a>
            <a href="<?= URL_BASE ?>index.php?pagina=informacion" class="<?= $claseActiva("informacion") ?>">Información</a>
            <a href="<?= URL_BASE ?>index.php?pagina=contacto" class="<?= $claseActiva("contacto") ?>">Contacto</a>
            <a href="<?= URL_BASE ?>index.php?pagina=login" class="btn-auth">Ingresar</a>
            <a href="<?= URL_BASE ?>index.php?pagina=registro" class="btn-outline<?= $claseActiva("registro") ?>">Registrarse</a>

        <?php else: ?>

            <!-- Menú privado (usuario con sesión) -->
            <a href="<?= URL_BASE ?>index.php?pagina=inventario" class="<?= $claseActiva("inventario") ?>">Inventario</a>
            <a href="<?= URL_BASE ?>index.php?pagina=pedidos" class="<?= $claseActiva("pedidos") ?>">Pedidos</a>
            <a href="<?= URL_BASE ?>index.php?pagina=proveedores" class="<?= $claseActiva("proveedores") ?>">Proveedores</a>

            <!-- Cerrar sesión se hace por POST para que un enlace ajeno no pueda cerrarla. -->
            <form action="<?= URL_BASE ?>procesos/usuario/cerrarSesion.php" method="post">
                <button type="submit" class="btn-salir">Salir</button>
            </form>

        <?php endif; ?>
    </nav>
</header>

<main>
