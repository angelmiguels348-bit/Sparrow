<?php if ($mensaje !== ""): ?>
    <!-- Mensaje de resultado de la última operación (htmlspecialchars evita HTML inyectado en la URL). -->
    <div class="mensaje <?= $tipo ?>" role="alert">
        <?= htmlspecialchars($mensaje) ?>
    </div>
<?php endif; ?>
