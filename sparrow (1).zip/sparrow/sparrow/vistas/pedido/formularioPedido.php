<h2>Gestión de Pedidos</h2>
<p style="font-size: 1.1rem;">Facilita el registro y seguimiento de pedidos y servicios relacionados.</p>

<form action="<?= URL_BASE ?>procesos/pedido/guardarPedido.php" method="post" style="margin-top: 20px;">

    <div class="form-group">
        <label for="txtCliente">Cliente / Destino del Pedido:</label>
        <input type="text" id="txtCliente" name="txtCliente" maxlength="150"
               placeholder="Ej: Empresa de Limpieza X"
               value="<?= htmlspecialchars($previo["txtCliente"] ?? "") ?>" required>
    </div>
    <div class="form-group">
        <label for="txtDescripcion">Descripción del Pedido:</label>
        <input type="text" id="txtDescripcion" name="txtDescripcion" maxlength="255"
               placeholder="Ej: 50 toallas rojas y 20 amarillas"
               value="<?= htmlspecialchars($previo["txtDescripcion"] ?? "") ?>" required>
    </div>

    <button type="submit" class="btn-submit">Registrar Pedido</button>
</form>
