<h2>Editar pedido</h2>
<p style="font-size: 1.1rem;">Modifica los datos y pulsa "Actualizar".</p>

<form action="<?= URL_BASE ?>procesos/pedido/actualizarPedido.php" method="post" style="margin-top: 20px;">

    <!-- El ID oculto indica exactamente qué registro se va a actualizar. -->
    <input type="hidden" name="id" value="<?= (int) $registro["id"] ?>">

    <div class="form-group">
        <label for="txtCliente">Cliente / Destino del Pedido:</label>
        <input type="text" id="txtCliente" name="txtCliente" maxlength="150"
               placeholder="Ej: Empresa de Limpieza X"
               value="<?= htmlspecialchars($previo["txtCliente"] ?? $registro["cliente"]) ?>" required>
    </div>
    <div class="form-group">
        <label for="txtDescripcion">Descripción del Pedido:</label>
        <input type="text" id="txtDescripcion" name="txtDescripcion" maxlength="255"
               placeholder="Ej: 50 toallas rojas y 20 amarillas"
               value="<?= htmlspecialchars($previo["txtDescripcion"] ?? $registro["descripcion"]) ?>" required>
    </div>

    <button type="submit" class="btn-submit">Actualizar</button>
    <a class="btn-cancelar" href="<?= URL_BASE ?>index.php?pagina=pedidos">Cancelar</a>
</form>
