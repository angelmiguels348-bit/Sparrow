<h2>Editar proveedor</h2>
<p style="font-size: 1.1rem;">Modifica los datos y pulsa "Actualizar".</p>

<form action="<?= URL_BASE ?>procesos/proveedor/actualizarProveedor.php" method="post" style="margin-top: 20px;">

    <!-- El ID oculto indica exactamente qué registro se va a actualizar. -->
    <input type="hidden" name="id" value="<?= (int) $registro["id"] ?>">

    <div class="form-group">
        <label for="txtNombre">Nombre del Proveedor:</label>
        <input type="text" id="txtNombre" name="txtNombre" maxlength="150"
               placeholder="Ej: Microfibras del Norte S.A."
               value="<?= htmlspecialchars($previo["txtNombre"] ?? $registro["nombre"]) ?>" required>
    </div>
    <div class="form-group">
        <label for="txtContacto">Teléfono o Contacto:</label>
        <input type="text" id="txtContacto" name="txtContacto" maxlength="100"
               placeholder="Ej: 300 123 4567"
               value="<?= htmlspecialchars($previo["txtContacto"] ?? $registro["contacto"]) ?>" required>
    </div>

    <button type="submit" class="btn-submit">Actualizar</button>
    <a class="btn-cancelar" href="<?= URL_BASE ?>index.php?pagina=proveedores">Cancelar</a>
</form>
