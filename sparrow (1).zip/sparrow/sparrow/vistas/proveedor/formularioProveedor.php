<h2>Administración de Proveedores</h2>
<p style="font-size: 1.1rem;">Organiza la información de los proveedores para mejorar el control de los productos.</p>

<form action="<?= URL_BASE ?>procesos/proveedor/guardarProveedor.php" method="post" style="margin-top: 20px;">

    <div class="form-group">
        <label for="txtNombre">Nombre del Proveedor:</label>
        <input type="text" id="txtNombre" name="txtNombre" maxlength="150"
               placeholder="Ej: Microfibras del Norte S.A."
               value="<?= htmlspecialchars($previo["txtNombre"] ?? "") ?>" required>
    </div>
    <div class="form-group">
        <label for="txtContacto">Teléfono o Contacto:</label>
        <input type="text" id="txtContacto" name="txtContacto" maxlength="100"
               placeholder="Ej: 300 123 4567"
               value="<?= htmlspecialchars($previo["txtContacto"] ?? "") ?>" required>
    </div>

    <button type="submit" class="btn-submit">Guardar Proveedor</button>
</form>
