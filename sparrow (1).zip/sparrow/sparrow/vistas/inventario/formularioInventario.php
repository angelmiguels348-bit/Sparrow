<h2>Registro de Inventario</h2>
<p style="font-size: 1.1rem;">Registra, consulta y administra las toallas en microfibra disponibles.</p>

<form action="<?= URL_BASE ?>procesos/inventario/guardarInventario.php" method="post" style="margin-top: 20px;">

    <div class="form-group">
        <label for="txtDetalle">Detalle o Tipo de Toalla:</label>
        <input type="text" id="txtDetalle" name="txtDetalle" maxlength="150"
               placeholder="Ej: Toalla Microfibra Azul 40x40cm"
               value="<?= htmlspecialchars($previo["txtDetalle"] ?? "") ?>" required>
    </div>
    <div class="form-group">
        <label for="txtCantidad">Cantidad Disponible:</label>
        <input type="number" id="txtCantidad" name="txtCantidad" min="0" max="1000000" step="1"
               placeholder="Ej: 100"
               value="<?= htmlspecialchars($previo["txtCantidad"] ?? "") ?>" required>
    </div>

    <button type="submit" class="btn-submit">Guardar en Inventario</button>
</form>
