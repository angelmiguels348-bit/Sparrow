<h3 style="margin-top:30px;">Inventario Actual:</h3>

<!-- Total calculado por el proceso de listado. -->
<p>Total de registros: <strong><?= (int) $total ?></strong></p>

<ul>
    <?php if ((int) $total === 0): ?>
        <li>No hay registros en esta sección aún.</li>
    <?php endif; ?>

    <?php while ($fila = $resultado->fetch_assoc()): ?>
        <li>
            <!-- htmlspecialchars protege la salida de datos escritos por usuarios. -->
            <span><strong><?= htmlspecialchars($fila["detalle"]) ?></strong> — <?= (int) $fila["cantidad"] ?> unidades</span>

            <div class="action-btns">
                <a class="btn-edit"
                   href="<?= URL_BASE ?>index.php?pagina=inventario-editar&id=<?= (int) $fila["id"] ?>">Editar</a>

                <form action="<?= URL_BASE ?>procesos/inventario/eliminarInventario.php" method="post"
                      data-confirmar="¿Estás seguro de que deseas eliminar este registro?">
                    <input type="hidden" name="id" value="<?= (int) $fila["id"] ?>">
                    <button type="submit" class="btn-delete">Eliminar</button>
                </form>
            </div>
        </li>
    <?php endwhile; ?>
</ul>
