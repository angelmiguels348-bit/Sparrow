<h2>Editar registro de inventario</h2>
<p style="font-size: 1.1rem;">Modifica los datos y pulsa "Actualizar".</p>

<form action="<?= URL_BASE ?>procesos/inventario/actualizarInventario.php" method="post" style="margin-top: 20px;">

    <!-- El ID oculto indica exactamente qué registro se va a actualizar. -->
    <input type="hidden" name="id" value="<?= (int) $registro["id"] ?>">

    <div class="form-group">
        <label for="txtDetalle">Detalle o Tipo de Toalla:</label>
        <input type="text" id="txtDetalle" name="txtDetalle" maxlength="150"
               placeholder="Ej: Toalla Microfibra Azul 40x40cm"
               value="<?= htmlspecialchars($previo["txtDetalle"] ?? $registro["detalle"]) ?>" required>
    </div>
    <div class="form-group">
        <label for="txtCantidad">Cantidad Disponible:</label>
        <input type="number" id="txtCantidad" name="txtCantidad" min="0" max="1000000" step="1"
               placeholder="Ej: 100"
               value="<?= htmlspecialchars($previo["txtCantidad"] ?? $registro["cantidad"]) ?>" required>
    </div>

    <button type="submit" class="btn-submit">Actualizar</button>
    <a class="btn-cancelar" href="<?= URL_BASE ?>index.php?pagina=inventario">Cancelar</a>
</form>
