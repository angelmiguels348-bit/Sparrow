<div class="login-container">
    <h2 style="margin-bottom: 20px; text-align: center;">Iniciar Sesión</h2>

    <form action="<?= URL_BASE ?>procesos/usuario/iniciarSesion.php" method="post">

        <div class="form-group">
            <label for="txtLogin">Usuario / Correo:</label>
            <input type="text" id="txtLogin" name="txtLogin" maxlength="100"
                   placeholder="Ej: admin" autocomplete="username"
                   value="<?= htmlspecialchars($previo["txtLogin"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label for="txtPassword">Contraseña:</label>
            <input type="password" id="txtPassword" name="txtPassword"
                   placeholder="Contraseña" autocomplete="current-password" required>
        </div>

        <button type="submit" class="btn-submit" style="background:#0088cc;">Entrar</button>
    </form>

    <p class="enlace-alterno">
        ¿Aún no tienes cuenta?
        <a href="<?= URL_BASE ?>index.php?pagina=registro">Regístrate aquí</a>
    </p>
</div>
