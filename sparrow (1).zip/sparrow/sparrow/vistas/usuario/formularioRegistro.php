<div class="login-container registro-container">
    <h2 style="margin-bottom: 20px; text-align: center;">Crear cuenta</h2>

    <form action="<?= URL_BASE ?>procesos/usuario/registrarUsuario.php" method="post" id="formRegistro">

        <div class="form-group">
            <label for="txtNombre">Nombre completo:</label>
            <input type="text" id="txtNombre" name="txtNombre" maxlength="80" data-sin-numeros
                   placeholder="Ej: María Fernanda Gómez" autocomplete="name"
                   value="<?= htmlspecialchars($previo["txtNombre"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label for="txtUsuario">Nombre de usuario:</label>
            <input type="text" id="txtUsuario" name="txtUsuario" maxlength="30"
                   pattern="[A-Za-z0-9_]{4,30}" autocomplete="username"
                   placeholder="Ej: maria_gomez"
                   value="<?= htmlspecialchars($previo["txtUsuario"] ?? "") ?>" required>
            <small class="form-hint">Entre 4 y 30 caracteres: letras, números o guion bajo.</small>
        </div>

        <div class="form-group">
            <label for="txtCorreo">Correo electrónico:</label>
            <input type="email" id="txtCorreo" name="txtCorreo" maxlength="100"
                   placeholder="correo@ejemplo.com" autocomplete="email"
                   value="<?= htmlspecialchars($previo["txtCorreo"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label for="txtPassword">Contraseña:</label>
            <input type="password" id="txtPassword" name="txtPassword" minlength="6" maxlength="72"
                   placeholder="Mínimo 6 caracteres" autocomplete="new-password" required>
            <small class="form-hint">Debe incluir al menos una letra y un número.</small>
        </div>

        <div class="form-group">
            <label for="txtPassword2">Confirmar contraseña:</label>
            <input type="password" id="txtPassword2" name="txtPassword2" minlength="6" maxlength="72"
                   placeholder="Repite la contraseña" autocomplete="new-password" required>
        </div>

        <button type="submit" class="btn-submit" style="background:#0088cc;">Crear cuenta</button>
    </form>

    <p class="enlace-alterno">
        ¿Ya tienes cuenta?
        <a href="<?= URL_BASE ?>index.php?pagina=login">Inicia sesión</a>
    </p>
</div>
