<h2>Contacto</h2>
<p style="margin-top:10px; font-size: 1.1rem;">
    ¿Tienes preguntas sobre el funcionamiento de la página? Puedes contactarme a través del siguiente formulario.
</p>

<form action="<?= URL_BASE ?>procesos/contacto/guardarContacto.php" method="post" style="margin-top:20px;">

    <div class="form-group">
        <label for="txtNombre">Nombre Completo:</label>
        <input type="text" id="txtNombre" name="txtNombre" maxlength="100" data-sin-numeros
               placeholder="Tu nombre"
               value="<?= htmlspecialchars($previo["txtNombre"] ?? "") ?>" required>
    </div>

    <div class="form-group">
        <label for="txtCorreo">Correo electrónico:</label>
        <input type="email" id="txtCorreo" name="txtCorreo" maxlength="100"
               placeholder="@gmail.com / @hotmail.com"
               value="<?= htmlspecialchars($previo["txtCorreo"] ?? "") ?>" required>
    </div>

    <div class="form-group">
        <label for="txtMensaje">Mensaje:</label>
        <textarea id="txtMensaje" name="txtMensaje" rows="4" maxlength="1000"
                  placeholder="Escribe tu mensaje..." required><?= htmlspecialchars($previo["txtMensaje"] ?? "") ?></textarea>
    </div>

    <button type="submit" class="btn-submit" style="background:#007bff;">Enviar</button>
</form>
