<div class="info-section">
  <h2>1. ¿Qué es SPARROW?</h2>
  <p>SPARROW es una aplicación web diseñada para facilitar la administración de toallas en microfibra. Permite organizar el inventario, gestionar pedidos y mantener un mejor control de los proveedores, evitando la pérdida de información y reduciendo el uso de registros manuales.</p>
</div>

<div class="info-section">
  <h2>2. ¿Qué puedes hacer con SPARROW?</h2>
  <div class="cards-grid">
    <div class="card">
      <h3>📦 Inventario</h3>
      <p>Registro y control de las toallas en microfibra disponibles.</p>
    </div>
    <div class="card">
      <h3>📋 Pedidos</h3>
      <p>Gestión y seguimiento de pedidos y servicios.</p>
    </div>
    <div class="card">
      <h3>👥 Proveedores</h3>
      <p>Registro y organización de la información de los proveedores.</p>
    </div>
  </div>
</div>

<div class="info-section">
  <h2>3. Beneficios del sistema</h2>
  <ul>
    <li>Facilita el control del inventario.</li>
    <li>Permite organizar la información.</li>
    <li>Reduce los errores en los registros manuales.</li>
    <li>Agiliza la gestión de pedidos.</li>
    <li>Mantiene la información centralizada.</li>
    <li>Permite un acceso controlado a los usuarios.</li>
  </ul>
</div>

<div class="info-section">
  <h2>4. Tecnologías utilizadas</h2>
  <div class="tech-box">
    <strong style="font-size:1.1rem; color:#0f172a;">HTML5 / CSS3</strong>
    <p>Estructura, diseño y adaptación de la página.</p>
  </div>
  <div class="tech-box">
    <strong style="font-size:1.1rem; color:#0f172a;">JavaScript</strong>
    <p>Funciones, validaciones y navegación del sistema.</p>
  </div>
  <div class="tech-box">
    <strong style="font-size:1.1rem; color:#0f172a;">PHP</strong>
    <p>Lógica del servidor, manejo de sesiones y conexión con la base de datos.</p>
  </div>
  <div class="tech-box">
    <strong style="font-size:1.1rem; color:#0f172a;">MySQL</strong>
    <p>Almacenamiento permanente de usuarios, inventario, pedidos y proveedores.</p>
  </div>
</div>

<hr style="margin: 30px 0; border: 0; border-top: 1px solid #ddd;">

<div class="info-section">
  <h2>Objetivo general</h2>
  <p>Optimizar el registro de toallas en microfibra, pedidos y proveedores para evitar la pérdida manual.</p>

  <h3 style="margin-top: 25px; font-size:1.3rem;">Objetivos específicos:</h3>
  <ul>
    <li><strong>Registro de inventario:</strong> Permitir registrar, consultar y administrar las toallas en microfibra disponibles.</li>
    <li><strong>Gestión de pedidos:</strong> Facilitar el registro y seguimiento de pedidos y servicios relacionados con las toallas.</li>
    <li><strong>Administración de proveedores:</strong> Organizar la información de los proveedores para mejorar el control de los productos.</li>
  </ul>
</div>
