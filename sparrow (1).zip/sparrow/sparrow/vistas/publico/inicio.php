<div class="hero-container">
    <div class="hero-text">
        <h1>Bienvenidos a SPARROW</h1>
        <p>Una página para la administración de bienes y servicios de toallas en microfibra.</p>

        <a class="btn-hero" href="<?= URL_BASE ?>index.php?pagina=login">Ingresar al sistema</a>
        <a class="btn-hero btn-hero-secundario" href="<?= URL_BASE ?>index.php?pagina=registro">Crear una cuenta</a>
    </div>

    <div class="hero-image">
        <img src="<?= URL_BASE ?>img/imagen.jpg" alt="Toallas de microfibra">
    </div>
</div>
