// =====================================================================
//  SPARROW - Funciones de apoyo del navegador
//  (la lógica del sistema está en PHP; aquí solo hay comodidades de
//   la interfaz. La validación real siempre se repite en el servidor.)
// =====================================================================

document.addEventListener('DOMContentLoaded', function () {

  // 1) Campos marcados con data-sin-numeros: elimina los números al escribir
  document.querySelectorAll('input[data-sin-numeros]').forEach(function (campo) {
    campo.addEventListener('input', function () {
      campo.value = campo.value.replace(/[0-9]/g, '');
    });
  });

  // 2) Formularios marcados con data-confirmar: piden confirmación antes de enviarse
  document.querySelectorAll('form[data-confirmar]').forEach(function (formulario) {
    formulario.addEventListener('submit', function (evento) {
      if (!confirm(formulario.dataset.confirmar)) {
        evento.preventDefault();
      }
    });
  });

  // 3) Registro: comprueba que las dos contraseñas coincidan
  var pass1 = document.getElementById('txtPassword');
  var pass2 = document.getElementById('txtPassword2');

  if (pass1 && pass2) {
    var comparar = function () {
      pass2.setCustomValidity(pass1.value !== pass2.value ? 'Las contraseñas no coinciden.' : '');
    };
    pass1.addEventListener('input', comparar);
    pass2.addEventListener('input', comparar);
  }

  // 4) Los mensajes de resultado se pueden cerrar con un clic
  document.querySelectorAll('.mensaje').forEach(function (aviso) {
    aviso.title = 'Clic para cerrar';
    aviso.style.cursor = 'pointer';
    aviso.addEventListener('click', function () { aviso.remove(); });
  });
});
